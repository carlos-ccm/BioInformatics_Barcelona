#random.py
import random

print("Numero random entre 0 y 1:",random.uniform(0,1))
print("Numero random entre 0 y 10:",random.uniform(0,10))
print("Numero random entre 0 y 10:",random.randint(0,10))
print("Numero random entre 0 y 1:",random.gauss(3,1)) #3 seria la mitja
