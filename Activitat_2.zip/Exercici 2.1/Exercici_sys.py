#sys.py
import sys

print(sys.argv)