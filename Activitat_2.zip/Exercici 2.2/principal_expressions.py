import Entregables.expressions as expressions

print(expressions.verificaCodi("08915"))
print(expressions.verificaCorreu("prueba@gmail.com"))
print(expressions.canviaNom("Carlos","Carla","Hola em dic Carlos"))