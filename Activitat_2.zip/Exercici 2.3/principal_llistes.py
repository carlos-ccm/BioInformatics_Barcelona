import llista

notes = 5

print(llista.generadorAleatori(notes))

print(llista.generaNotesAlumne(5,"Clara"))
